import boto3
import awswrangler as wr
import logging
import os
import traceback

# ---------------- Logging Setup ----------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ---------------- AWS Clients ----------------
s3 = boto3.client("s3")
lambda_client = boto3.client("lambda")

def lambda_handler(event, context):
    logger.info("🚀 Lambda 2 (Split Transformed Parquet) triggered.")
    logger.info(f"📨 Incoming event: {event}")

    try:
        # ✅ Get environment variable
        bucket = os.environ.get("BUCKET_NAME")
        if not bucket:
            raise EnvironmentError("❌ Missing required environment variable: BUCKET_NAME")

        # Process each record from S3 event
        for record in event.get("Records", []):
            key = record["s3"]["object"]["key"]

            # Skip irrelevant files
            if not key.startswith("transformed/") or not key.endswith(".parquet"):
                logger.info(f"⏩ Skipping non-transformed file: {key}")
                continue

            s3_path = f"s3://{bucket}/{key}"
            logger.info(f"📂 Reading transformed parquet from: {s3_path}")

            # ✅ Read transformed data directly from S3
            df = wr.s3.read_parquet(path=s3_path)
            logger.info(f"📊 Loaded {len(df)} rows from {s3_path}")

            # ✅ Create dimension tables
            dim_product = df[["product_name", "category"]].drop_duplicates()
            dim_date = df[["crawl_year", "crawl_month"]].drop_duplicates()

            # ✅ Create fact table
            fact_sales = df[[
                "product_name",
                "current_discounted_price",
                "listed_price",
                "rating",
                "number_of_reviews",
                "discount_amount",
                "discount_flag",
                "rating_bucket",
                "crawl_year",
                "crawl_month"
            ]]

            # ✅ Write curated parquet outputs back to S3
            curated_outputs = {
                "curated/dim_product.parquet": dim_product,
                "curated/dim_date.parquet": dim_date,
                "curated/fact_sales.parquet": fact_sales
            }

            for output_key, frame in curated_outputs.items():
                output_path = f"s3://{bucket}/{output_key}"
                wr.s3.to_parquet(df=frame, path=output_path, index=False)
                logger.info(f"✅ Uploaded {output_path} with {len(frame)} rows")

        # ✅ Once all parquet files are written, trigger Lambda 3
        try:
            lambda_client.invoke(
                FunctionName="lambda-load-redshift",
                InvocationType="Event"  # async trigger
            )
            logger.info("🚀 Successfully triggered Lambda 3 (Load to Redshift).")
        except Exception as e:
            logger.error(f"❌ Failed to trigger Lambda 3: {e}")

        logger.info("🎯 Lambda 2 completed successfully.")
        return {"status": "success", "message": "Curated parquet files generated."}

    except Exception as e:
        logger.error(f"💥 Lambda 2 failed: {e}")
        logger.error(traceback.format_exc())
        return {"status": "error", "message": str(e)}
